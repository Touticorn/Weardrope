// Netlify Function: Anthropic Claude proxy
// Keeps ANTHROPIC_API_KEY server-side.

const cors = (extra = {}) => ({
  "Access-Control-Allow-Origin": "*",
  ...extra,
});

export default async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
      },
    });
  }

  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: cors({ "Content-Type": "application/json" }),
    });
  }

  const ANTHROPIC_API_KEY = Netlify.env.get("ANTHROPIC_API_KEY");
  if (!ANTHROPIC_API_KEY) {
    return new Response(JSON.stringify({
      error: "ANTHROPIC_API_KEY not configured. Add it in Netlify Site Settings → Environment Variables, then redeploy.",
    }), { status: 500, headers: cors({ "Content-Type": "application/json" }) });
  }

  try {
    const body = await req.json();
    const { messages, max_tokens = 1200, model = "claude-sonnet-4-20250514" } = body;

    if (!Array.isArray(messages)) {
      return new Response(JSON.stringify({ error: "messages array required" }), {
        status: 400,
        headers: cors({ "Content-Type": "application/json" }),
      });
    }

    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "x-api-key": ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ model, max_tokens, messages }),
    });

    const text = await r.text();
    return new Response(text, {
      status: r.status,
      headers: cors({ "Content-Type": "application/json" }),
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: "Proxy error", detail: String(err.message || err) }), {
      status: 502,
      headers: cors({ "Content-Type": "application/json" }),
    });
  }
};

export const config = {
  path: "/api/claude",
};
